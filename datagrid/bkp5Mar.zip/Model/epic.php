<?php 
namespace Phppot\Model;

use Phppot\Datasource;

class epic
{
    private $ds;
    
  function __construct()
  {
        require_once __DIR__ . './../lib/DataSource.php';
        $this->ds = new DataSource();
  }

    /**
     * to get the all value
     *
     * @return array result record
     */
  function getFAQ() 
  {
     
        $query= "SELECT f.*,fs.name as fname,pi.pi_title as ptitle,tp.name as tname
        FROM features AS f
        LEFT JOIN feature_statuses AS fs ON fs.id = f.f_status_id
        LEFT JOIN productincrements AS pi ON pi.pi_id = f.f_PI
        LEFT JOIN topics AS tp ON tp.id = f.f_topic_id";                 
        $result = $this->ds->select($query);
        //print '<pre>';print_r($result);
        return $result;
  }

  function topics()
  {

         $topics = "SELECT * from topics";
         $topicsresult = $this->ds->select($topics);  
         //print_r($topicsresult);
         return $topicsresult;
  }

  function getPI()
  {

        $PI = "SELECT * from productincrements";
        $PIresult = $this->ds->select($PI);  
        //print_r($PIresult);
        return $PIresult;
  }

 function status()
 {

        $status = "SELECT * from feature_statuses";
        $statusresult = $this->ds->select($status);  
        //print_r($statusresult);
        return $statusresult;
 }
    
  function epics()
  {

    $epics = "SELECT * from epics";
    $epicsresult = $this->ds->select($epics);  
    //print_r($PIresult);
    return $epicsresult;
  }
    
    /**
     * to edit redorcbased on the question_id
     *
     * @param string $columnName
     * @param string $columnValue
     * @param string $questionId
     */
    function editRecord($columnName, $columnValue, $questionId) 
    {
       
        $query = "UPDATE features set " . $columnName . " = ? WHERE  f_id = ?";
        $paramType = 'si';
        $paramValue = array($columnValue,$questionId);
        $this->ds->execute($query, $paramType, $paramValue);
    }
// ******************************Start Epics**********************

  function getTeam() 
  {
     
        $query="SELECT * FROM epics
        LEFT JOIN team
        ON team.id = epics.team_id";
        $result = $this->ds->select($query);
        //print '<pre>';print_r($result);
        return $result;
  }

  function team()
  {
       $team = "SELECT * from team";
        $teamresult = $this->ds->select($team);  
      //print '<pre>';print_r($teamresult);
        return $teamresult;
  }



//Update..

  function epicseditRecord($columnName, $columnValue, $questionId) 
  {
        $query = "UPDATE epics set " . $columnName . " = ? WHERE  e_id = ?";
        $paramType = 'si';
        $paramValue = array($columnValue,$questionId);
        $this->ds->execute($query, $paramType, $paramValue);
  }
// ******************************End Epics************************


// ******************************Start Staff**********************
function getStaff() 
  {
     
        $query= "SELECT s.*,teamname.name as teamname,topic.name as topicname
        FROM staff AS s
        LEFT JOIN team AS teamname ON teamname.id = s.staff_team_id
        LEFT JOIN topics AS topic ON topic.id = s.staff_topic_id";                 
        $result = $this->ds->select($query);
        
        return $result;
  }


  function staffeditRecord($columnName, $columnValue, $questionId) 
  {
        $query = "UPDATE staff set " . $columnName . " = ? WHERE  staff_id = ?";
        $paramType = 'si';
        $paramValue = array($columnValue,$questionId);
        $this->ds->execute($query, $paramType, $paramValue);
  }

// ******************************End Staff************************


// ******************************Start Topics**********************

  function getTopics()
  {

         $topics = "SELECT * from topics";
         $topicsresult = $this->ds->select($topics);  
         //print_r($topicsresult);
         return $topicsresult;
  }

    function topicseditRecord($columnName, $columnValue, $questionId) 
  {
        $query = "UPDATE topics set " . $columnName . " = ? WHERE  id = ?";
        $paramType = 'si';
        $paramValue = array($columnValue,$questionId);
        $this->ds->execute($query, $paramType, $paramValue);
  }

// ******************************End Topics************************


// ******************************Start Topics**********************

  function getProductInc()
  {
         $productInc = "SELECT * from productincrements";
         $productIncresult = $this->ds->select($productInc);  
         //print_r($productIncresult);
         return $productIncresult;
  }



   function productInceditRecord($columnName, $columnValue, $questionId) 
  {
        $query = "UPDATE productincrements set " . $columnName . " = ? WHERE  pi_id = ?";
        $paramType = 'si';
        $paramValue = array($columnValue,$questionId);
        $this->ds->execute($query, $paramType, $paramValue);
  }

// ******************************End Topics************************


}